
const knex = require('../connection')

const tablename2 = 'items'

class itemsmodel {

    getallitems = async()=>{
        return  await knex.select('*')
        .from(tablename2)
    }

    getitembyid = async(item_id)=>{
        return   await knex(tablename2)
        .where('item_id', item_id)
    }

    additem = async(body) => {
        const data = await knex(tablename2).insert(body)
        const item_id = data[0]
        return await knex(tablename2)
        .where('item_id', item_id)
    }

    deleteitem = async(item_id) => {
        return await knex(tablename2)
        .where('item_id', item_id)
        .del()
    }

    updateitem = async(item_id , body)=>{
        return await knex(tablename2)
        .where('item_id', item_id)
        .update(body)
    }

}

module.exports = new itemsmodel()