const knex = require('../connection')

class viewsmodel {

    itemsview = async()=> {
        return  await knex.select('*')
        .from('items_view')
    }

    ordersview = async()=> {
        return await knex.select('*')
        .from('orders_view')
    }
}

module.exports = new viewsmodel()