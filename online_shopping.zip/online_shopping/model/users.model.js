const knex = require('../connection')


const tablename3 = 'users'


class usersmodel {
    
    getallusers = async()=> {
        return await knex.select('*')
        .from(tablename3)
    }

    getuserbyid = async(user_id)=>{
        return await knex(tablename3)
        .where('user_id', user_id)
    }

    adduser = async(body) =>{
        const data = await knex(tablename3).insert(body)
        const user_id = data[0]
        return await knex(tablename3)
        .where('user_id', user_id)
    }

    deleteuser = async(user_id) => {
        return await knex(tablename3)
        .where('user_id', user_id)
        .del()
    }

    updateuser = async(user_id , body) => {
        return await knex(tablename3)
        .where('user_id', user_id)
        .update(body)
    }
}

module.exports = new usersmodel()