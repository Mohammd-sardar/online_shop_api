const knex = require('../connection')
const tablename = 'brands'

class brandsmodel {

    getallbrands = async()=> {
        return await knex.select('*')
        .from(tablename) 
    }

    getbrandbyid = async(brand_id)=> {
            return await knex(tablename)
           .where('brand_id', brand_id)
    }

    addbrand = async(body) => {
        const id = await knex(tablename).insert(body)
            const brand_id = id[0]
            return await knex(tablename)
          .where('brand_id', brand_id)
    }

    deletebrand = async(brand_id)=>{
        return await knex(tablename)
          .where('brand_id', brand_id)
          .del()
    }

    updatebrand = async(brand_id , body)=>{
        return await knex(tablename)
            .where('brand_id',  brand_id)
            .update(body)
    }

}

module.exports = new brandsmodel()