
const knex = require('../connection')

const tablename4 = 'orders'

class ordersmodel {

    getallorders = async()=>{
        return  await knex.select('*')
        .from(tablename4)
    }

    getorderbyid = async(order_id)=>{
        return await knex(tablename4)
            .where('order_id', order_id)
    }

    getorderbyuserid = async(user_id)=>{
        return await knex(tablename4)
            .where('user_id', user_id)
    }

    addorder = async(body)=> {
        const data = await knex(tablename4).insert(body)
            const order_id = data[0]
            return await knex(tablename4)
            .where('order_id', order_id)
    }

    deleteorder = async(order_id)=> {
        return await knex(tablename4)
        .where('order_id', order_id)
        .del()
    }

    updateorder = async(order_id , body)=> {
        return await knex(tablename4)
            .where('order_id', order_id)
            .update(body)
    }
}


module.exports = new ordersmodel()