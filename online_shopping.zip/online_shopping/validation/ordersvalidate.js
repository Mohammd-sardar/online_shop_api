const Joi = require('joi');

class validation {

    createvalidate = (body)=> {
        const schema = Joi.object({
            order_date: Joi.date().required() , 
            item_id : Joi.number().integer().required() , 
            order_qty : Joi.number().integer().required() , 
            order_price : Joi.number().required() ,
            user_id : Joi.number().integer().required()


        })

        return schema.validate(body)

    }
}

module.exports = new validation()