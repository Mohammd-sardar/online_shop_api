const Joi = require('joi');

class validation {

    createvalidate = (body)=> {
        const schema = Joi.object({
            item_name : Joi.string().required() ,
            item_barcode : Joi.number().integer().required() ,
            item_image_url : Joi.string().required() , 
            brand_id : Joi.number().integer().required() , 
            item_available_qty : Joi.number().integer().required()
        })

        return schema.validate(body)

    }
}

module.exports = new validation()