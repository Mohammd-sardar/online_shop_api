const Joi = require('joi');

class validation {

    createvalidate = (body)=> {
        const schema = Joi.object({
            user_name: Joi.string().required() 
        })

        return schema.validate(body)

    }
}

module.exports = new validation()