const express = require('express')
const app = express()

const brands = require('../controller/brands.controller')

// ************************ //
  //tabele of brands starts 



  //this route for retrieving all brands
app.get('/get_brands' , brands.getallbrands()) 
 
 //this route for retrieving a brand by id
app.get('/get_brands/:brand_id' , brands.getbrandbyid())

 //this route for adding new brands 
app.post('/add_brand' , brands.addbrand())

 //this route for deleting a brand by id
app.delete('/delete_brand/:brand_id' , brands.deletebrand() )

 //this route for updating a brand by id
app.put('/update_brand/:brand_id' , brands.updatebrand() ) 


// table of brands ends 
// ************************ //

module.exports = app