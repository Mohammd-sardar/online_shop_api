const express = require('express')
const app = express()

const users = require('../controller/users.controller')

// ************************ //
  //tabele of users starts



 //this route for retrieving all users
  app.get('/get_users' , users.getallusers() )


  //this route for retrieving a user by id
  app.get('/get_users/:user_id' , users.getuserbyid() )

  //this route for adding new users
  app.post('/add_user' , users.adduser() )


  //this route for deleting a user by id
  app.delete('/delete_user/:user_id' , users.deleteuser() )

  //this route for updating a user by id
  app.put('/update_user/:user_id' , users.updateuser() )


   // table of users ends 
// ************************ //

module.exports = app
