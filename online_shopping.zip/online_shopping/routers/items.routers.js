const express = require('express')
const app = express()

const items = require('../controller/items.controller')

// ************************ // 
  //tabele of items starts 




  //this route for retrieving all items
  app.get('/get_items' , items.getallitems() )


   //this route for retrieving an item by id
  app.get('/get_items/:item_id' , items.getitembyid() )


  //this route for adding new items
  app.post('/add_item' ,items.additem() )


 //this route for deleting a item by id
  app.delete('/delete_item/:item_id' ,items.deleteitem() )


  //this route for updating an item by id
  app.put('/update_item/:item_id' ,items.updateitem() )



  // table of items ends 
// ************************ //

module.exports = app