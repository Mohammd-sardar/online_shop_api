const express = require('express')
const app = express()

const orders = require('../controller/orders.controller')


// ************************ //
  //tabele of orders starts



 //this route for retrieving all orders
  app.get('/get_orders' , orders.getallorders() )


  //this route for retrieving an order by id
  app.get('/get_orders/:order_id' , orders.getorderbyid() )

    //this route for retrieving an order by id
  app.get('/get_orders/user/:user_id' , orders.getorderbyuserid() )

  //this route for adding new orders
  app.post('/add_order' , orders.addorder() )


  //this route for deleting an order by id
  app.delete('/delete_order/:order_id' , orders.deleteorder() )

  //this route for updating an order by id
  app.put('/update_order/:order_id' , orders.updateorder() )


   // table of orders ends  
// ************************ //

module.exports = app