const express = require("express")
const app = express()

const views = require('../controller/views.controller')

//start views //
//*********************** //

//items_view 
app.get('/items_view' , views.itemsview())
  
//orders_view 
app.get('/orders_view' , views.ordersview() )
  
  //end views //
  //*********************** //

  module.exports = app