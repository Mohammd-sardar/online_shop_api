
const brandsmodel = require('../model/brands.model')
const validation = require('../validation/brandsvalidate')


class brands {

    getallbrands = () =>{
        return async(req , res)=> {
             brandsmodel.getallbrands().then((data) => {
                res.send(data)
             }).catch((err) => {
                res.send(err)
             })
            
        }
    }

    getbrandbyid = () => {
        return async(req , res)=> {
        const brand_id = req.params.brand_id
           brandsmodel.getbrandbyid(brand_id).then((data) => {
            res.send(data)
           }).catch((err) => { 
            res.send(err)
           }); 
         }
    }

    addbrand = ()=> {
        return async(req , res)=> {
            const body = req.body

            if(validation.createvalidate(body).error)
            {
                res.send(validation.createvalidate(body).error.details[0].message)
            }
            else
            {
                brandsmodel.addbrand(body).then((data) => {
                res.send(data)  
                }).catch((err) => {
                    res.send(err)
                });
            }
            
        }
    }

    deletebrand = () => {
        return async(req , res)=>{
            const brand_id = req.params.brand_id
            brandsmodel.deletebrand(brand_id).then((data) => {
                res.send('deleted')
            }).catch((err) => {
                res.send(err)
            });
        }
    }

    updatebrand = () => {
        return async(req,res)=>{
            const body = req.body
            const brand_id = req.params.brand_id
            
            if(validation.createvalidate(body).error)
            {
                res.send(validation.createvalidate(body).error.details[0].message)
            }
            else
            {
                brandsmodel.updatebrand(brand_id , body).then((data) => {
                res.send("updated")
                }).catch((err) => {
                    res.send(err)
                });
            }
           
            
        }

    }
}

module.exports = new brands()