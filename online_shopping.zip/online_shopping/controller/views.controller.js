const viewsmodel = require('../model/views.model')

class views {

    itemsview = ()=> {
        return async(req,res)=>{
            viewsmodel.itemsview().then((data) => {
                res.send(data)
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    ordersview = ()=>{
        return async(req,res)=>{
           viewsmodel.ordersview().then((data) => {
            res.send(data)
           }).catch((err) => {
            res.send(err)
           });
            
          }
    }

}

module.exports = new views()