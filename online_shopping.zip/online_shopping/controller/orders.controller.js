
const ordersmodel = require('../model/orders.model')
const validation = require('../validation/ordersvalidate')

class orders {

    getallorders = ()=> {
        return async(req,res)=>{
            ordersmodel.getallorders().then((data) => {
                res.send(data)
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    getorderbyid = ()=> {
        return async(req,res)=>{
            const order_id = req.params.order_id
            ordersmodel.getorderbyid(order_id).then((data) => {
                res.send(data)
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    getorderbyuserid = ()=> {
        return async(req,res)=>{
            const user_id = req.params.user_id
            ordersmodel.getorderbyuserid(user_id).then((data) => {
                res.send(data)
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    addorder = ()=> {
        return async (req,res)=>{
            const body = req.body

            if(validation.createvalidate(body).error)
            {
                res.send(validation.createvalidate(body).error.details[0].message)
            }

            else
            {
                ordersmodel.addorder(body).then((data) => {
                res.send(data)
                }).catch((err) => {
                    res.send(err)
                });
            }
            
            
          }
    }

    deleteorder = ()=> {
        return async (req,res)=>{
            const order_id = req.params.order_id
            ordersmodel.deleteorder(order_id).then((data) => {
                res.send("deleted")
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    updateorder = ()=> {
       return  async(req,res)=>{
            const body= req.body
            const order_id = req.params.order_id
            if(validation.createvalidate(body).error)
            {
                res.send(validation.createvalidate(body).error.details[0].message)
            }
            
            else
            {
                ordersmodel.updateorder(order_id , body).then((data) => {
                    res.send('updated')
                }).catch((err) => {
                    res.send(err)
                });
            }
            
          }
    }
}

module.exports = new orders()