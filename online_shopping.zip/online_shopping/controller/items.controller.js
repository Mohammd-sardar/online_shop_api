
const itemsmodel = require('../model/items.model')
const validation = require('../validation/itemsvalidate')

class items {

    getallitems = ()=> {
        return async(req,res)=>{
            itemsmodel.getallitems().then((data) => {
                res.send(data)
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    getitembyid = ()=> {
        return async(req , res)=> {
            const item_id = req.params.item_id
            itemsmodel.getitembyid(item_id).then((data) => {
                res.send(data) 
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    additem = ()=> {
        return async(req,res)=>{

            const body = req.body

            if(validation.createvalidate(body).error)
            {
                res.send(validation.createvalidate(body).error.details[0].message)
            }

            else
            {
                itemsmodel.additem(body).then((data) => {
                res.send(data)
                }).catch((err) => {
                    res.send(err)
                });
            }
           
          }
    }

    deleteitem = ()=> {
        return async(req,res)=>{
            const item_id = req.params.item_id
           itemsmodel.deleteitem(item_id).then((data) => {
             res.send("deleted")
           }).catch((err) => {
             res.send(err)
           });
         
          }
    }

    updateitem = ()=> {
        return async(req,res)=>{
            const body = req.body
            const item_id = req.params.item_id
            
            if(validation.createvalidate(body).error)
            {
                res.send(validation.createvalidate(body).error.details[0].message)
            }
            else
            {
                itemsmodel.updateitem(item_id , body)
                res.send('updated')
            }
            
          }
    }
}

module.exports = new items()