const usersmodel = require('../model/users.model')
const validation = require('../validation/usersvalidate')

class users {

    getallusers = ()=> {
        return async(req,res)=> {
            usersmodel.getallusers().then((data) => {
                res.send(data)
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    getuserbyid = ()=> {
        return async(req,res)=>{
            const user_id = req.params.user_id
            usersmodel.getuserbyid(user_id).then((data) => {
                res.send(data)
            }).catch((err) => {
                res.send(err)
            });
             
          }
    }


    adduser = ()=>{
        return async (req,res)=>{
            const body = req.body

            if(validation.createvalidate(body).error)
            {
                res.send(validation.createvalidate(body).error.details[0].message)
            }

            else
            {
                    usersmodel.adduser(body).then((data) => {
                    res.send(data)
                }).catch((err) => {
                    res.send(err)
                });
            }
           
            
          }
    }


    deleteuser = ()=> {
        return async (req,res)=>{
            const user_id = req.params.user_id
            usersmodel.deleteuser(user_id).then((data) => {
                res.send("deleted")
            }).catch((err) => {
                res.send(err)
            });
            
          }
    }

    updateuser = ()=>{
        return async(req,res)=>{
            const body= req.body
            const user_id = req.params.user_id

            if(validation.createvalidate(body).error)
            {
                res.send(validation.createvalidate(body).error.details[0].message)
            }
            else
            {
                usersmodel.updateuser(user_id ,body).then((data) => {
                res.send('updated')
                }).catch((err) => {
                    res.send(err)
                });
            }
            
            
          }
    }
}

module.exports = new users()
