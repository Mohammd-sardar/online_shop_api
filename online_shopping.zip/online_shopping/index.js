const express = require("express")
const app = express()
const port = 5000
const body_parser = require('body-parser')
app.use(body_parser.json())


const brands = require('./routers/brands.routers')
app.use('/' , brands)
  

const items = require('./routers/items.routers')
app.use('/' , items)


const users = require('./routers/users.routers')
app.use('/' , users)



const orders = require('./routers/orders.routers')
app.use('/' , orders)


const views = require('./routers/views.routers')
app.use('/' , views)



app.listen(port , ()=>{
    console.log("wa run dabi");
})