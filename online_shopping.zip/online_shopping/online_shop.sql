

--
-- Database: `online_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`) VALUES
(3, 'Nike'),
(4, 'Adidas'),
(5, 'bazar'),
(6, 'kwfa'),
(10, 'yori');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_barcode` int(11) NOT NULL,
  `item_image_url` varchar(200) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `item_available_qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `item_barcode`, `item_image_url`, `brand_id`, `item_available_qty`) VALUES
(3, 'klaw', 12345678, 'klaw.png', 3, 20),
(4, 'T-shirt', 234890, 't.jpg', 4, 40),
(7, 'babwj', 907542, 'babuj4.png', 3, 30);

-- --------------------------------------------------------

--
-- Stand-in structure for view `items_view`
-- (See below for the actual view)
--
CREATE TABLE `items_view` (
`item_id` int(11)
,`item_name` varchar(100)
,`item_barcode` int(11)
,`item_image_url` varchar(200)
,`brand_id` int(11)
,`item_available_qty` int(11)
,`brand_name` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `item_id` int(11) NOT NULL,
  `order_qty` int(11) NOT NULL,
  `order_price` float NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_date`, `item_id`, `order_qty`, `order_price`, `user_id`) VALUES
(3, '2023-03-24', 3, 2, 3000, 3),
(4, '2023-03-31', 4, 3, 6000, 4),
(5, '2023-03-24', 3, 2, 3000, 3),
(6, '2024-03-23', 7, 2, 5000, 4);

-- --------------------------------------------------------

--
-- Stand-in structure for view `orders_view`
-- (See below for the actual view)
--
CREATE TABLE `orders_view` (
`order_id` int(11)
,`order_date` date
,`item_id` int(11)
,`order_qty` int(11)
,`order_price` float
,`user_id` int(11)
,`item_name` varchar(100)
,`item_image_url` varchar(200)
,`brand_id` int(11)
,`brand_name` varchar(100)
,`user_name` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`) VALUES
(3, 'ayum'),
(4, 'mohammed'),
(5, 'shera2'),
(7, 'karwan');

-- --------------------------------------------------------

--
-- Structure for view `items_view`
--
DROP TABLE IF EXISTS `items_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `items_view`  AS SELECT `items`.`item_id` AS `item_id`, `items`.`item_name` AS `item_name`, `items`.`item_barcode` AS `item_barcode`, `items`.`item_image_url` AS `item_image_url`, `items`.`brand_id` AS `brand_id`, `items`.`item_available_qty` AS `item_available_qty`, `brands`.`brand_name` AS `brand_name` FROM (`items` join `brands`) WHERE `items`.`brand_id` = `brands`.`brand_id` ;

-- --------------------------------------------------------

--
-- Structure for view `orders_view`
--
DROP TABLE IF EXISTS `orders_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `orders_view`  AS SELECT `orders`.`order_id` AS `order_id`, `orders`.`order_date` AS `order_date`, `orders`.`item_id` AS `item_id`, `orders`.`order_qty` AS `order_qty`, `orders`.`order_price` AS `order_price`, `orders`.`user_id` AS `user_id`, `items`.`item_name` AS `item_name`, `items`.`item_image_url` AS `item_image_url`, `items`.`brand_id` AS `brand_id`, `brands`.`brand_name` AS `brand_name`, `users`.`user_name` AS `user_name` FROM (((`orders` join `items`) join `brands`) join `users`) WHERE `orders`.`item_id` = `items`.`item_id` AND `items`.`brand_id` = `brands`.`brand_id` AND `orders`.`user_id` = `users`.`user_id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`brand_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;


